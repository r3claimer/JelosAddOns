#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2019-present Shanti Gilbert (https://github.com/shantigilbert)
# Copyright (C) 2020-present Fewtarius
# Copyright (C) 2022-present Brooksytech

# Load functions needed to send messages to the console
. /etc/profile

LINK="https://github.com/brooksytech/JelosAddOns/raw/main/duckstation_libretro.tar.gz"
SHASUM="708b2ae973ae93c41c6f4700f973be5ad4c4a6699510e86f7607e3d0e114f3c0"

INSTALL_PATH="/storage/.config/retroarch/cores"
BINARY="drastic"
LINKDEST="${INSTALL_PATH}/duckstation_libretro.tar.gz"
START_SCRIPT="$BINARY.sh"


mkdir -p "${INSTALL_PATH}"

curl -Lo $LINKDEST $LINK
CHECKSUM=$(sha256sum $LINKDEST | awk '{print $1}')
if [ ! "${SHASUM}" == "${CHECKSUM}" ]
then
  rm "${LINKDEST}"
  exit 1
fi

tar xvf $LINKDEST -C "${INSTALL_PATH}"
rm $LINKDEST

