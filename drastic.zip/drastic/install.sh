#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2019-present Shanti Gilbert (https://github.com/shantigilbert)
# Copyright (C) 2020-present Fewtarius
# Copyright (C) 2022-present Brooksytech

# Load functions needed to send messages to the console
. /etc/profile

unset MYARCH
MYARCH="aarch64"
LINK="https://github.com/brooksytech/JelosAddOns/raw/main/drastic.tar.gz"
SHASUM="c3fa571739f42bbd6e9a68e725b8678e4f1202d284939b61e11fe8d8b00a0d22"

INSTALL_PATH="/storage/.config/drastic"
BINARY="drastic"
LINKDEST="${INSTALL_PATH}/${MYARCH}/drastic.tar.gz"
CFG="/storage/.emulationstation/es_systems.cfg"
START_SCRIPT="$BINARY.sh"


mkdir -p "${INSTALL_PATH}/${MYARCH}/"

curl -Lo $LINKDEST $LINK
CHECKSUM=$(sha256sum $LINKDEST | awk '{print $1}')
if [ ! "${SHASUM}" == "${CHECKSUM}" ]
then
  rm "${LINKDEST}"
  exit 1
fi

tar xvf $LINKDEST -C "${INSTALL_PATH}/${MYARCH}/"
rm $LINKDEST

if [ ! -d $CFG ]
then
  cp /etc/emulationstation/es_systems.cfg $CFG
fi

if grep -q '<name>nds</name>' "$CFG"
then
	xmlstarlet ed -L -P -d "/systemList/system[name='nds']" $CFG
fi

	echo 'Adding Drastic to systems list'
	xmlstarlet ed --omit-decl --inplace \
		-s '//systemList' -t elem -n 'system' \
		-s '//systemList/system[last()]' -t elem -n 'name' -v 'nds'\
		-s '//systemList/system[last()]' -t elem -n 'fullname' -v 'Nintendo DS'\
		-s '//systemList/system[last()]' -t elem -n 'path' -v '/storage/roms/nds'\
		-s '//systemList/system[last()]' -t elem -n 'manufacturer' -v 'Nintendo'\
		-s '//systemList/system[last()]' -t elem -n 'release' -v '2005'\
		-s '//systemList/system[last()]' -t elem -n 'hardware' -v 'portable'\
		-s '//systemList/system[last()]' -t elem -n 'extension' -v '.nds .zip .NDS .ZIP'\
		-s '//systemList/system[last()]' -t elem -n 'command' -v "/storage/.config/drastic/$START_SCRIPT %ROM%"\
		-s '//systemList/system[last()]' -t elem -n 'platform' -v 'nds'\
		-s '//systemList/system[last()]' -t elem -n 'theme' -v 'nds'\
		$CFG

read -d '' content <<EOF
#!/bin/bash

source /etc/profile

BINPATH="/usr/bin"
EXECLOG="/var/log/exec.log"

cd ${INSTALL_PATH}/${MYARCH}/drastic/
maxperf
./drastic "\$1" >> \$EXECLOG 2>&1
normperf
EOF
echo "$content" > ${INSTALL_PATH}/${START_SCRIPT}
chmod +x ${INSTALL_PATH}/${START_SCRIPT}
if [ ! -d "${INSTALL_PATH}/${MYARCH}/drastic/config" ]
then
  mkdir ${INSTALL_PATH}/${MYARCH}/drastic/config
fi
cp device/`echo "${HW_DEVICE}"`/drastic.cfg ${INSTALL_PATH}/${MYARCH}/drastic/config
#cp drastic/RG552/drastic.cfg ${INSTALL_PATH}/${MYARCH}/drastic/config 2>/dev/null ||:

### 1.0 compatibility
#if [ -f "/storage/.config/emuelec/scripts/drastic.sh" ]
#then
#  rm -f "/storage/.config/emuelec/scripts/drastic.sh"
#fi

### Only link on 1.0 as 2.0 paths are different.
#if [ -d "/storage/.config/emuelec/scripts" ]
#then
#  ln -sf ${INSTALL_PATH}/${START_SCRIPT} /storage/.config/emuelec/scripts/drastic.sh
#fi
