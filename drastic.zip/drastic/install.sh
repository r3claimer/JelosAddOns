#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2019-present Shanti Gilbert (https://github.com/shantigilbert)
# Copyright (C) 2020-present Fewtarius
# Copyright (C) 2022-present Brooksytech

# Load functions needed to send messages to the console
. /etc/profile

unset MYARCH
MYARCH="aarch64"
LINK="https://github.com/brooksytech/JelosAddOns/raw/main/drastic.tar.gz"
SHASUM="c3fa571739f42bbd6e9a68e725b8678e4f1202d284939b61e11fe8d8b00a0d22"

INSTALL_PATH="/storage/.config/drastic"
BINARY="drastic"
LINKDEST="${INSTALL_PATH}/${MYARCH}/drastic.tar.gz"
CFG="/storage/.emulationstation/es_systems.cfg"
START_SCRIPT="$BINARY.sh"


mkdir -p "${INSTALL_PATH}/${MYARCH}/"

curl -Lo $LINKDEST $LINK
CHECKSUM=$(sha256sum $LINKDEST | awk '{print $1}')
if [ ! "${SHASUM}" == "${CHECKSUM}" ]
then
  rm "${LINKDEST}"
  exit 1
fi

tar xvf $LINKDEST -C "${INSTALL_PATH}/${MYARCH}/"
rm $LINKDEST

#!/bin/bash

source /etc/profile

BINPATH="/usr/bin"
EXECLOG="/var/log/exec.log"

cd ${INSTALL_PATH}/${MYARCH}/drastic/
maxperf
./drastic "\$1" >> \$EXECLOG 2>&1
normperf
EOF
echo "$content" > ${INSTALL_PATH}/${START_SCRIPT}
chmod +x ${INSTALL_PATH}/${START_SCRIPT}
if [ ! -d "${INSTALL_PATH}/${MYARCH}/drastic/config" ]
then
  mkdir ${INSTALL_PATH}/${MYARCH}/drastic/config
fi
cp device/`echo "${HW_DEVICE}"`/drastic.cfg ${INSTALL_PATH}/${MYARCH}/drastic/config

