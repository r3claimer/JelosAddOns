#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2019-present Shanti Gilbert (https://github.com/shantigilbert)
# Copyright (C) 2020-present Fewtarius
# Copyright (C) 2022-present Brooksytech

# Load functions needed to send messages to the console
. /etc/profile


INSTALL_PATH="/storage/.config/drastic"
BINARY="drastic"
CFG="/storage/.emulationstation/es_systems.cfg"
START_SCRIPT="$BINARY.sh"

MYARCH="aarch64"

if [ -f /storage/.config/emulationstation/scripts/drastic.sh ]
then
  rm -f /storage/.config/emulationstation/scripts/drastic.sh
fi

rm -rf ${INSTALL_PATH}
