#!/bin/bash

/usr/bin/retroarch -L ./tyrquake_libretro.so /roms/ports/quake/dopa/pak0.pak