#!/bin/bash
/usr/bin/retroarch -L ./tyrquake_libretro.so /roms/ports/quake/rogue/pak0.pak