#!/bin/bash

/usr/bin/retroarch -L ./tyrquake_libretro.so /roms/ports/quake/hipnotic/pak0.pak