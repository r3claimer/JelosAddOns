not zip files
Doom2.wad  (ROM)
prboom.wad   (bios)
This files are require inside this directory (doom2) for port to work
