#!/bin/bash
/usr/bin/retroarch -L /storage/roms/ports/ecwolf_libretro/ecwolf_libretro.so /roms/ports/ecwolf_libretro/WOLF3D.EXE
